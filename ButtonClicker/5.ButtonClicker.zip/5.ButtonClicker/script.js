function change(element){element.remove()};

function toggle(element){
    element.innerText = "Log Out"
 }